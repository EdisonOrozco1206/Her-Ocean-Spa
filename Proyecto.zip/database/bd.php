<?php
if (!defined("SCRIPT_ROOT")) {
    define('SCRIPT_ROOT', '//localhost/Proyecto/');
}
$connect = new mysqli("localhost" , "root" , "", "her_ocean_spa");
?> 