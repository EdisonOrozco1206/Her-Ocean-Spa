<?php
define('SCRIPT_ROOT', '//localhost/Proyecto/');
?>
<link rel="stylesheet" href="<?= SCRIPT_ROOT ?>back-office/styles-bo.css">
<div class="container_bo">
   <div class="form-container">
        <h1>Bienvenido cliente</h1>
</div>
</div>