<?php include('layouts/header.php') ?>

<div class="index-container">

</div>

<?php include('layouts/footer.php') ?>