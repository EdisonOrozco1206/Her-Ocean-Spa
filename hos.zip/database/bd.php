<?php
$connect = new mysqli("localhost" , "root" , "", "her_ocean_spa");
?> 